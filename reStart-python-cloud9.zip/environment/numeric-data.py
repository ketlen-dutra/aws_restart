print("Python has three numeric types: int, float, and complex")

#tipo inteiro
myValue=1
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))

#tipo float
tipoFloat=3.14
print(tipoFloat)
print(type(tipoFloat))
print(str(tipoFloat) + " is of the data type " + str(type(tipoFloat)))

#tipo complex
tipoComplex=5j
print(tipoComplex)
print(type(tipoComplex))
print(str(tipoComplex) + " is of the data type " + str(type(tipoComplex)))

#tipos booleanos
tipoBool=True
print(tipoBool)
print(type(tipoBool))
print(str(tipoBool) + " is of the data type " + str(type(tipoBool)))

tipoBool2=False
print(tipoBool2)
print(type(tipoBool2))
print(str(tipoBool2) + " is of the data type " + str(type(tipoBool2)))
